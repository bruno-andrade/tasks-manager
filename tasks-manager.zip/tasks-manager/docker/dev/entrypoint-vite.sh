#!/bin/sh

npm install

exec "$@"